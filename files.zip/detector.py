from ultralytics import YOLO

# Load model once
model = YOLO("yolov8n-face.pt")

def detect_faces(frame):
    results = model(frame)
    faces = []
    for box in results[0].boxes:
        x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
        conf = float(box.conf[0])
        if conf > 0.5:
            faces.append({'bbox': (x1, y1, x2, y2), 'conf': conf})
    return faces
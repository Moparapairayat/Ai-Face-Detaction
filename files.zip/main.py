import cv2
from detector import detect_faces
from recognizer import recognize_faces, load_known_faces
from emotion import detect_emotions
from tracker import FaceTracker
from antispoof import is_live_face
from analytics import analyze_faces

# Load known faces for recognition
known_face_encodings, known_face_names = load_known_faces('known_faces/')

# Initialize tracker
tracker = FaceTracker()

# Start video capture
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Step 1: Face Detection
    faces = detect_faces(frame)

    # Step 2: Tracking
    tracked_faces = tracker.update(faces, frame)

    for face in tracked_faces:
        x1, y1, x2, y2 = face['bbox']
        face_img = frame[y1:y2, x1:x2]

        # Step 3: Anti-Spoofing
        liveness = is_live_face(face_img)
        if not liveness:
            label = "Spoof"
            color = (0,0,255)
        else:
            # Step 4: Recognition
            name = recognize_faces(face_img, known_face_encodings, known_face_names)
            # Step 5: Emotion
            emotion = detect_emotions(face_img)
            label = f"{name} ({emotion})"
            color = (0,255,0)

        # Step 6: Draw Results
        cv2.rectangle(frame, (x1,y1), (x2,y2), color, 2)
        cv2.putText(frame, label, (x1, y1-10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

    # Step 7: Analytics
    frame = analyze_faces(frame, tracked_faces)

    cv2.imshow("Advanced Face AI", frame)
    if cv2.waitKey(1) & 0xFF == 27:  # ESC
        break

cap.release()
cv2.destroyAllWindows()
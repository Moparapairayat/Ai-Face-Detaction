from deepface import DeepFace

def detect_emotions(face_img):
    try:
        result = DeepFace.analyze(face_img, actions=['emotion'], enforce_detection=False)
        return result['dominant_emotion']
    except Exception:
        return "N/A"
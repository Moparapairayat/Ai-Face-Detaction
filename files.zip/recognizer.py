import face_recognition
import os

def load_known_faces(folder):
    encodings = []
    names = []
    for file in os.listdir(folder):
        img = face_recognition.load_image_file(os.path.join(folder, file))
        encoding = face_recognition.face_encodings(img)
        if encoding:
            encodings.append(encoding[0])
            names.append(os.path.splitext(file)[0])
    return encodings, names

def recognize_faces(face_img, known_face_encodings, known_face_names):
    rgb = face_img[:, :, ::-1]
    encodings = face_recognition.face_encodings(rgb)
    if encodings:
        matches = face_recognition.compare_faces(known_face_encodings, encodings[0])
        if True in matches:
            return known_face_names[matches.index(True)]
    return "Unknown"
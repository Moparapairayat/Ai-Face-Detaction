import cv2
import numpy as np

def is_live_face(face_img):
    # Simple liveness check: variance of Laplacian
    gray = cv2.cvtColor(face_img, cv2.COLOR_BGR2GRAY)
    var = cv2.Laplacian(gray, cv2.CV_64F).var()
    return var > 15  # Threshold can be tuned
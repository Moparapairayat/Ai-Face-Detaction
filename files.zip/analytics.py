import cv2

def analyze_faces(frame, tracked_faces):
    count = len(tracked_faces)
    cv2.putText(frame, f"Faces: {count}", (10,30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,0), 2)
    return frame
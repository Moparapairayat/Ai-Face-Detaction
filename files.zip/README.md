# Advanced AI Face Detection System

## Features

- Face Detection (YOLOv8-face)
- Face Recognition
- Emotion Detection
- Face Tracking
- Anti-Spoofing (Liveness)
- Analytics Overlay

## Setup

1. Clone repo & install requirements:
    ```
    pip install -r requirements.txt
    ```
2. Download YOLOv8-face weights (`yolov8n-face.pt`) and place in project root.
3. Put reference images in `known_faces/` folder (filename = person's name).
4. Run:
    ```
    python main.py
    ```